package pl.polsl.gr6.proj.io.DoggyFoodie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoggyFoodieApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoggyFoodieApplication.class, args);
	}

}
