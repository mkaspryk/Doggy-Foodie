package pl.polsl.gr6.proj.io.DoggyFoodie.repositories;

import org.springframework.data.repository.CrudRepository;
import pl.polsl.gr6.proj.io.DoggyFoodie.model.User;

/**
 *
 * @author Radosław Płachta
 * @version 1.0
 */
public interface UserRepository extends CrudRepository<User, Integer> {

}
