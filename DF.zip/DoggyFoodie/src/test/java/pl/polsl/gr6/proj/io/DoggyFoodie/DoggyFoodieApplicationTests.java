package pl.polsl.gr6.proj.io.DoggyFoodie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoggyFoodieApplicationTests {

	@Test
	void contextLoads() {
	}

}
